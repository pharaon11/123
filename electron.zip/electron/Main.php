<?php

class Main
{

    private $db;

    /**
     * Подключение к БД
     */
    public function __construct()
    {
        $this->db = new PDO('mysql:host=10.100.3.80;dbname=19103_electron', '19103', 'mpbqto');
    }
	//Работа с данными продуктов
    public function getProducts(): array
    {
        return ($this->db->query('SELECT * FROM products JOIN categories ON (products.id_category=categories.id_categories)'))->fetchAll();
    }
	//Работа с данными категорий
    public function getCategories(): array
    {
        return ($this->db->query('SELECT * FROM categories'))->fetchAll();
    }
	//Работа с данными пользователей
    public function getUsers(): array
    {
        return ($this->db->query('SELECT * FROM users'))->fetchAll();
    }
	//Работа с данными продаж
    public function getSales(): array
    {
        return ($this->db->query('SELECT * FROM sales JOIN users ON (sales.id_users = users.id)'))->fetchAll();
    }
	//Работа с данными товаров в продажах
    public function getSalprod(): array
    {
        return ($this->db->query('SELECT * FROM sales_products JOIN sales ON (sales_products.id_sale = sales.id_sales) JOIN products ON (sales_products.id_product = products.id_product)'))->fetchAll();
    }

	//Удаление категорий
    public function deleteCat(int $id_categories): bool
    {
        return ($this->db->prepare("DELETE FROM categories WHERE id_categories = ?"))->execute([$id_categories]);
    }

    //Удаление продукта
    public function deleteProd(int $id_product): bool
    {
        return ($this->db->prepare("DELETE FROM products WHERE id_product = ?"))->execute([$id_product]);
    }

}
?>