<?php
include_once "connectDB.php";
include_once "./Main.php";
$products = (new Main())->getProducts();
$categories = (new Main())->getCategories();

/*if($_SESSION['roles'] == '1')
  {*/
?>
<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Электроника</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

  </head>
  <body>
  <nav class="navbar bg-light">
  <div class="container-fluid justify-content-center">
    <a class="navbar-brand" href="index.php">
      Электроника
    </a>
    <ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="products_red.php">Товары</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="categories_red.php">Категории</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="users_red.php">Пользователи</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="sales_get.php">Заказы</a>
  </li>
  <?php 
  if (isset($_SESSION['loggedin']) === true)
  {?>
  <li class="nav-item">
    <a class="nav-link" href="?exit">Выход</a>
  </li>
  <?php } ?>
  <?php 
                if(isset($_GET['exit']))
                {
                    session_destroy();
                    header('Location: login.php');
                    exit;
                } ?>
</ul>
  </div>
</nav>
<div class="container">
    <h2 class="sub-title"> Добавление продукта </h2>
        <?php
            if (isset($_POST["id_category"]) AND isset($_POST["name_product"]) AND isset($_POST["description"]) AND isset($_POST["price"])) {
                try {
                    $sql = "INSERT INTO products (id_category, name_product, description, price) VALUES (:id_category, :name_product, :description, :price)";
                    // определяем prepared statement
                    $stmt = $dbh->prepare($sql);
                    // привязываем параметры к значениям
                    $stmt->bindValue(":id_category", $_POST["id_category"]);
                    $stmt->bindValue(":name_product", $_POST["name_product"]);
                    $stmt->bindValue(":description", $_POST["description"]);
                    $stmt->bindValue(":price", $_POST["price"]);
                    // выполняем prepared statement
                    $affectedRowsNumber = $stmt->execute();
                    // если добавлена как минимум одна строка
                    if($affectedRowsNumber > 0 ){
                        header('Refresh: 1; url=products_red.php');  
                    }
                }
                catch (PDOException $e) {
                    echo "Database error: " . $e->getMessage();
                }
            }
            ?>
            <form method="post" class="form" style="max-width:50%">
            <label for="exampleInputEmail1">Категория</label>
                <select class="form-select" name="id_category">
                    <option> Выберите категорию </option>
                    <?php foreach ($categories as $row): ?>
                    <option value=<?php echo $row['id_categories']?>><?php echo $row['name_categories']?></option>
                    <?php endforeach; ?>
                </select>
                <p>Название:
                <input type="text" class="form-control" name="name_product" /></p>
                <p>Описание:
                <input type="text" class="form-control" name="description" /></p>
                <p>Стоимость:
                <input type="number" class="form-control" name="price" /></p>
                <input type="submit" class="btn btn-success" value="Добавить">
            </form>
    </div>
    <br>
<div class="container">
<table class="table">
    <thead>
        <tr class="table-dark">
        <th scope="col">Категория</th>
        <th scope="col">Название</th>
        <th scope="col">Описание</th>
        <th scope="col">Цена</th>
        <th scope="col">Изменить</th>
        <th scope="col">Удалить</th>
            </tr>
    </thead>
    <tbody>
<?php foreach ($products as $row):?>
        <tr>
            <td><?=$row['name_categories']?> </td>
            <td><?=$row['name_product']?> </td>
            <td><?=$row['description']?> </td>
            <td><?=$row['price']?> </td>
            <td>Изменить</td>
            <td><button onclick="del(<?= $row['id_product'] ?>)" type="button" class="btn btn-danger btn-sm"> Удалить </button></td>
        </tr>
<?php endforeach; ?>
    </tbody>
</table>
</div>
<script>
   
function del(id_product)
    {
        $.ajax({
            url: 'controller/DeleteProd.php',         /* Куда пойдет запрос */
            method: 'get',             /* Метод передачи (post или get) */
            dataType: 'html',          /* Тип данных в ответе (xml, json, script, html). */
            data: {id_product: id_product},     /* Параметры передаваемые в запросе. */
            success: function(){   /* функция которая будет выполнена после успешного запроса.  */
                location.reload();
            }
        });
    }

</script>
<?php //}?>

<!--<p>Нет доступа</p>-->