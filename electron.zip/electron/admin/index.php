<?php
include_once "connectDB.php";
include_once "Main.php";

/*if($_SESSION['roles'] == '1')
  {*/
?>
<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Электроника</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
  <body>
  <nav class="navbar bg-light">
  <div class="container-fluid justify-content-center">
    <a class="navbar-brand" href="index.php">
      Электроника
    </a>
    <ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="products_red.php">Товары</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="categories_red.php">Категории</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="users_red.php">Пользователи</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="sales_get.php">Заказы</a>
  </li>

  <?php 
  if (isset($_SESSION['loggedin']) === true)
  {?>
  <li class="nav-item">
    <a class="nav-link" href="?exit">Выход</a>
  </li>
  <?php } ?>
  <?php 
                if(isset($_GET['exit']))
                {
                    session_destroy();
                    header('Location: login.php');
                    exit;
                } ?>
</ul>
  </div>
</nav>

<div class="container">
<div class="btn-group-vertical" role="group" aria-label="Vertical button group"> <br>
<a href="create_categories.php"> <button type="button" class="btn btn-success">Добавить категорию</button></a><br>
<a href="create_products.php"><button type="button" class="btn btn-success">Добавить товар</button></a><br>
</div>

</div>

<?php //}?>

<!--<p>Нет доступа</p>-->