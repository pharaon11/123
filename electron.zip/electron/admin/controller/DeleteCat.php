<?php

require_once "././Main.php";

    return (new Main())->deleteCat($_GET['id_categories']);

