<?php

require_once "././Main.php";

    return (new Main())->deleteProd($_GET['id_product']);

