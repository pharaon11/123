<?php
include_once "connectDB.php";
include_once "./Main.php";
$categories = (new Main())->getCategories();
/*if($_SESSION['roles'] == '1')
  {*/
?>
<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Электроника</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>

  </head>
  <body>
  <nav class="navbar bg-light">
  <div class="container-fluid justify-content-center">
    <a class="navbar-brand" href="index.php">
      Электроника
    </a>
    <ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="products_red.php">Товары</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="categories_red.php">Категории</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="users_red.php">Пользователи</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="sales_get.php">Заказы</a>
  </li>
  <?php 
  if (isset($_SESSION['loggedin']) === true)
  {?>
  <li class="nav-item">
    <a class="nav-link" href="?exit">Выход</a>
  </li>
  <?php } ?>
  <?php 
                if(isset($_GET['exit']))
                {
                    session_destroy();
                    header('Location: login.php');
                    exit;
                } ?>
</ul>
  </div>
</nav>
<div class="container">
    <h2 class="sub-title"> Добавление категории </h2>
        <?php
            if (isset($_POST["name_categories"])) {
                try {
                    $sql = "INSERT INTO categories (name_categories) VALUES (:name_categories)";
                    // определяем prepared statement
                    $stmt = $dbh->prepare($sql);
                    // привязываем параметры к значениям
                    $stmt->bindValue(":name_categories", $_POST["name_categories"]);
                    // выполняем prepared statement
                    $affectedRowsNumber = $stmt->execute();
                    // если добавлена как минимум одна строка
                    if($affectedRowsNumber > 0 ){
                        header('Refresh: 1; url=categories_red.php');  
                    }
                }
                catch (PDOException $e) {
                    echo "Database error: " . $e->getMessage();
                }
            }
            ?>
            <form method="post" class="form" style="max-width:50%">
                <p>Название:
                <input type="text" class="form-control" name="name_categories" /></p>
                <input type="submit" class="btn btn-success" value="Добавить">
            </form>
    </div>
    <br>
<div class="container">
<table class="table">
    <thead>
        <tr class="table-dark">
        <th scope="col">Название</th>
        <th scope="col">Изменить</th>
        <th scope="col">Удалить</th>
            </tr>
    </thead>
    <tbody>
<?php foreach ($categories as $row):?>
        <tr>
            <td><?=$row['name_categories']?> </td>
            <td><a type="button" class="btn btn-outline-success btn-sm" href="update-cat.php?id_categories=<?= $row['id_categories'] ?>">Изменить</a></td>
            <td><button onclick="del(<?= $row['id_categories'] ?>)" type="button" class="btn btn-danger btn-sm"> Удалить </button></td>
        </tr>
<?php endforeach; ?>
    </tbody>
</table>
</div>

<script>
   
function del(id_categories)
    {
        $.ajax({
            url: 'controller/DeleteCat.php',         /* Куда пойдет запрос */
            method: 'get',             /* Метод передачи (post или get) */
            dataType: 'html',          /* Тип данных в ответе (xml, json, script, html). */
            data: {id_categories: id_categories},     /* Параметры передаваемые в запросе. */
            success: function(){   /* функция которая будет выполнена после успешного запроса.  */
                location.reload();
            }
        });
    }

</script>
<?php //}?>

<!--<p>Нет доступа</p>-->