<?php
require_once "./connectDB.php";
?>
<!DOCTYPE html>
<html lang="ru">
<body>
   <link rel="stylesheet" href="../styles/style.css"> 
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

</body>
<head>
    <body style="margin-top: 2%;">
        <div class="container" style="display: block; text-align: center;">
        <?php
// если запрос GET
if($_SERVER["REQUEST_METHOD"] === "GET" AND isset($_GET["id_categories"]))
{
    $cat = $_GET["id_categories"];
    $sql = "SELECT * FROM `categories` WHERE id_categories = :cat";
    $mass = $dbh->prepare($sql);
    $mass->bindValue(":cat", $cat);
    // выполняем выражение и получаем данные по id
    $mass->execute();
    if($mass->rowCount() > 0){
        foreach ($mass as $row) {
            $name_categories = $row['name_categories'];
        }?>

<h3 class="sub-title">Изменение категории</h3>
<hr>

  <div class="rows">
  <form method='POST' class="forms" style="max-width:50%">

     <div class="form-control" style = "text-align:center;">

                  <input type='hidden' name='id_categories' value='<?= $row['id_categories']?>' />
                  <p>Название:
                  <input class="form-control" type='text' name='name_categories' value='<?= $row['name_categories']?>' /></p>

                  <input class="btn btn-primary" type='submit' value='Сохранить' />
      </div>
  </form>
  </div>

   <?php }
    else{
        echo "Категория не найдена";
    }
}
elseif (isset($_POST["id_categories"]) OR isset($_POST["name_categories"])) {

    $sql = "UPDATE categories SET name_categories = :name_categories WHERE id_categories = :cat";
    $serv = $dbh->prepare($sql);
    $serv->bindValue(":cat", $_POST["id_categories"]);
    $serv->bindValue(":name_categories", $_POST["name_categories"]);
    $serv->execute();
    header("Location: categories_red.php");
}
else{
    echo "Некорректные данные";
}
?>
        </div>
    </body>
</html>