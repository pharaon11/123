<?php
include_once "connectDB.php";
include_once "./Main.php";
$sales = (new Main())->getSales();
$salprod = (new Main())->getSalprod();
/*if($_SESSION['roles'] == '1')
  {*/
?>
<!doctype html>
<html lang="ru">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Электроника</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>
  <body>
  <nav class="navbar bg-light">
  <div class="container-fluid justify-content-center">
    <a class="navbar-brand" href="index.php">
      Электроника
    </a>
    <ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="products_red.php">Товары</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="categories_red.php">Категории</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="users_red.php">Пользователи</a>
  </li>
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="sales_get.php">Заказы</a>
  </li>
  <?php 
  if (isset($_SESSION['loggedin']) === true)
  {?>
  <li class="nav-item">
    <a class="nav-link" href="?exit">Выход</a>
  </li>
  <?php } ?>
  <?php 
                if(isset($_GET['exit']))
                {
                    session_destroy();
                    header('Location: login.php');
                    exit;
                } ?>
</ul>
  </div>
</nav>
<div class="container">
<table class="table">
    <thead>
        <tr class="table-dark">
        <th scope="col">Клиент</th>
        <th scope="col">Дата продажи</th>
        <th scope="col">Товары</th>
            </tr>
    </thead>
    <tbody>
<?php foreach ($sales as $row):?>
        <tr>
            <td><?=$row['full_name']?> </td>
            <td><?=$row['data_sales']?> </td>
            <td>
            <?php
            foreach ($salprod as $key=>$rows){
                if($row['id_sale'] = $rows['id_sales']){?>
            <?=++$key;?>. <?=$rows['name_product']?><br>
            <?php }} ?></td>
        </tr>
<?php endforeach; ?>
    </tbody>
</table>
</div>

<?php //}?>

<!--<p>Нет доступа</p>-->