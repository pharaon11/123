<!DOCTYPE html>
<html lang="en">
<?php
// Проверка входа пользователя в систему, если да, переходит на страницу приветствия
if (isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true) {
    header("location: index.php");
    exit;
}
require_once "connectDB.php";
//Определите переменные и инициализируйте пустыми значениями
$login = $password = "";
$login_err = $password_err = $username_err = "";
//Обработка данных формы при отправке
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //Проверка ввода логина
    if (empty(trim($_POST["login"]))) {
        $login_err = "Пожалуйста, введите Ваш логин!";
    } else {
        $login = trim($_POST["login"]);
    }
    //Проверка ввода пароля
    if (empty(trim($_POST["password"]))) {
        $password_err = "Пожалуйста, введите Ваш пароль!";
    } else {
        $password = trim($_POST["password"]);
    }
    //Подтверждение данных
    if (empty($username_err) && empty($password_err)) {
        //Подготовьте оператор выбора
        $sql = "SELECT id, login, password FROM users WHERE login = :login";
        if ($stmt = $dbh->prepare($sql)) {
            //Привяжите переменные к подготовленному оператору как параметры
            $stmt->bindParam(":login", $param_login, PDO::PARAM_STR);
            //Установить параметры
            $param_login = trim($_POST["login"]);
            //Попытка выполнить подготовленный оператор
            if ($stmt->execute()) {
                //Проверьте, существует ли имя пользователя, если да, то подтвердите пароль
                if ($stmt->rowCount() == 1) {
                    if ($row = $stmt->fetch()) {
                        $id = $row["id"];
                        $login = $row["login"];
                        $hashed_password = $row["password"];
                        $roles = $row["roles"];
                        if (password_verify($password, $hashed_password)) {
                            //Хранить данные в переменных сеанса
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $id;
                            $_SESSION["login"] = $login;
                            $_SESSION["roles"] = $roles;
                            //Перенаправить пользователя на страницу приветствия
                            header("location: index.php");
                        } else {
                            //Пароль недействителен, отображается общее сообщение об ошибке
                            $username_err = "Неправильный логин или пароль!";
                        }
                    }
                } else {
                    //Имя пользователя не существует, отобразить общее сообщение об ошибке
                    $username_err = "Неправильный логин или пароль!";
                }
            } else {
                echo "Ой! Что-то пошло не так. Пожалуйста, повторите попытку позже.";
            }
            unset($stmt);
        }
    }
    unset($conn);
}
?>


<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>Авторизация</title>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

</head>

<body>


<div class="container tm-mt-big tm-mb-big">
    <div class="row">
        <div class="col-6 mx-auto tm-login-col">
            <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
                <div class="row">
                    <div class="col-12 text-center">
                        <h2 class="tm-block-title mb-4">Добро пожаловать!</h2>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-offset-3 col-md-6">

                        <?php
                        if (!empty($username_err)) {
                            echo '<div class="alert alert-danger">' . $username_err . '</div>';
                        }
                        ?>

                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="tm-login-form">

                            <div class="form-group">
                                <input type="text" name="login" placeholder="Логин" class="form-control <?php echo (!empty($login_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $login; ?>">
                                <span class="invalid-feedback"><?php echo $login_err; ?></span>
                            </div>

                            <div class="form-group mt-3">
                                <input type="password" name="password" placeholder="Пароль" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                                <span class="invalid-feedback"><?php echo $password_err; ?></span>
                            </div>
                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-primary btn-block">Войти</button>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.3.1.min.js"></script>
<!-- https://jquery.com/download/ -->
<script src="js/bootstrap.min.js"></script>
<!-- https://getbootstrap.com/ -->
</body>
</html>
