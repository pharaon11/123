<!DOCTYPE html>
<html lang="en">

<?php
// Include config file
require_once "connectDB.php";

// Define variables and initialize with empty values
$login = $password = $confirm_password = "";
$login_err = $password_err = $confirm_password_err = "";

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){

    // Validate username
    if(empty(trim($_POST["login"]))){
        $login_err = "Пожалуйста, введите Ваш логин!";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["login"]))){
        $login_err = "Имя пользователя может содержать только буквы, цифры и символы подчеркивания.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE login = :login";


        if($stmt = $dbh->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":login", $param_login, PDO::PARAM_STR);

            // Set parameters
            $param_login = trim($_POST["login"]);

            // Attempt to execute the prepared statement
            if($stmt->execute()){
                if($stmt->rowCount() == 1){
                    $login_err = "Пользователь с таким именем уже существует.";
                } else{
                    $login = trim($_POST["login"]);
                }
            } else{
                echo "Ой! Что-то пошло не так. Пожалуйста, повторите попытку позже.";
            }

            // Close statement
            unset($stmt);
        }
    }

    // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Пожалуйста, введите пароль!";
    } elseif(strlen(trim($_POST["password"])) < 6){
        $password_err = "Пароль должен состоять не менее чем из 6 символов.";
    } else{
        $password = trim($_POST["password"]);
    }

    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Пожалуйста, подтвердите пароль!";
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Пароль не совпадает.";
        }
    }

    // Check input errors before inserting in database
    if(empty($login_err) && empty($password_err) && empty($confirm_password_err)){

        // Prepare an insert statement
        $sql = "INSERT INTO users (login, password) VALUES (:login, :password)";

        if($stmt = $dbh->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(":login", $param_login, PDO::PARAM_STR);
            $stmt->bindParam(":password", $param_password, PDO::PARAM_STR);

            // Set parameters
            $param_login = $login;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash

            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Redirect to login page
                header("location:login.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            unset($stmt);
        }
    }

    // Close connection
    unset($conn);
}
?>


<head>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta http-equiv="X-UA-Compatible" content="ie=edge"/>
    <title>Регистрация</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.7/css/bootstrap.min.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />

</head>

<body>


<div class="container tm-mt-big tm-mb-big">
    <div class="row">
        <div class="col-6 mx-auto tm-login-col">
            <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
                <div class="row">
                    <div class="col-6 text-center">
                        <h2 class="tm-block-title mb-4">Регистрация</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-offset-3 col-md-6">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="tm-login-form">
                            <div class="form-group">
                                <input type="text" name="login" placeholder="Логин" class="form-control <?php echo (!empty($login_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $login; ?>">
                                <span class="invalid-feedback"><?php echo $login_err; ?></span>
                            </div>

                            <div class="form-group mt-3">
                                <input type="password" name="password" placeholder="Пароль" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $password; ?>">
                                <span class="invalid-feedback"><?php echo $password_err; ?></span>
                            </div>

                            <div class="form-group mt-3">
                                <input type="password" name="confirm_password" placeholder="Подтвердите пароль" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $confirm_password; ?>">
                                <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
                            </div>

                            <div class="form-group mt-4">
                                <button type="submit" class="btn btn-primary btn-block">Создать аккаунт</button>
                            </div>


                            <p class="text-center small">Есть аккаунт? <a href="login.php">Вход</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-3.3.1.min.js"></script>
<!-- https://jquery.com/download/ -->
<script src="js/bootstrap.min.js"></script>
<!-- https://getbootstrap.com/ -->
</body>
</html>
